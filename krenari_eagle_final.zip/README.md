
# Krenari Eagle — 3D Chrome Intro for AZR Auto Group
A modern Three.js website scaffold, featuring a self-rooting 3D chrome Albanian eagle intro animation. Ready for Netlify, with full GLB support (Draco, KTX2/Basis, Meshopt).

## ✨ Features
- ⚡ **3D Chrome Intro** — Animated eagle docks to the corner after a clean hero intro.
- 🌐 **Netlify-Ready** — No CDNs; local modules; `netlify.toml` to publish repo root.
- 🛠 **Full Loader Support** — DRACO, KTX2/Basis, Meshopt all included.
- 📱 **Responsive** — Works great on iOS/Android and desktop.
- 🚀 **Expandable** — Solid base for the rest of the dealership website.

## Deploy (GitHub → Netlify)
1. Create a new GitHub repo and upload these files at the repo root (`index.html`, `libs/`, etc.).
2. In Netlify: **Add new site → Import from GitHub**.
3. Build settings: **Build command:** *(leave empty)*, **Publish directory:** `.`
4. Deploy. Visit your site.
5. (Optional) Commit `eagle.glb` to the repo root to load your model (fallback spinner appears if missing).

## Notes
- If your GLB is Draco/KTX2/Meshopt compressed, decoders are already wired.
- Cache-bust: append `?v=2` to your site URL after updates.
